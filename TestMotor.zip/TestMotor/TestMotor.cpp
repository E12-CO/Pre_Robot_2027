#include "TestMotor.h"

static int _in1;
static int _in2;

void initMotor(int in1, int in2) {
  _in1 = in1;
  _in2 = in2;
  pinMode(_in1, OUTPUT);
  pinMode(_in2, OUTPUT);
  
  digitalWrite(_in1, LOW);
  digitalWrite(_in2, LOW);
}

void spinMotor(int direction) {
  if (direction == 1) {

    digitalWrite(_in1, HIGH);
    digitalWrite(_in2, LOW);
  } 
  else if (direction == -1) {
    digitalWrite(_in1, LOW);
    digitalWrite(_in2, HIGH);
  } 
  else {
    digitalWrite(_in1, LOW);
    digitalWrite(_in2, LOW);
  }
}