#ifndef TEST_MOTOR_H
#define TEST_MOTOR_H

#include <Arduino.h>

void initMotor(int in1, int in2);

void spinMotor(int direction);

#endif