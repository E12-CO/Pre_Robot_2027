#include <TestMotor.h>

const int IN1 = 5; 
const int IN2 = 6; 

void setup() {
  initMotor(IN1, IN2);
}

void loop() {
  spinMotor(1);   // Forward
  delay(2000);
  
  spinMotor(0);   // Stop
  delay(1000);
  
  spinMotor(-1);  // Backward
  delay(2000);
  
  spinMotor(0);   // Stop
  delay(1000);
}