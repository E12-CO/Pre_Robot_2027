#include "TestIR.h"

static int _irPin;

void initIR(int pin) {
  _irPin = pin;
  Serial.begin(9600); 
  pinMode(_irPin, INPUT);       
  pinMode(LED_BUILTIN, OUTPUT); 
  digitalWrite(LED_BUILTIN, LOW);
}

void scanIR() {
  if (digitalRead(_irPin) == LOW) {
    Serial.println("Object Detected!");
    
    digitalWrite(LED_BUILTIN, HIGH); 
    delay(100);                      
    digitalWrite(LED_BUILTIN, LOW);  
    
    delay(200); 
  }
}