#include <TestIR.h>

const int IR_PIN = 2; // <=== Choose Pin

void setup() {
  initIR(IR_PIN); 
}

void loop() {
  scanIR(); 
}