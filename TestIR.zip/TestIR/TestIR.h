#ifndef TEST_IR_H
#define TEST_IR_H

#include <Arduino.h>

void initIR(int pin);  
void scanIR();          
#endif